package com.cricket.service.scoring;
import com.cricket.dto.DeliveryRequest;import com.cricket.entity.*;import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class ScoringRulesTest {
 @Test void wideIsNotLegalBall(){ExtraType type=ExtraType.WIDE;assertFalse(type!=ExtraType.WIDE&&type!=ExtraType.NO_BALL);}
 @Test void noBallIsNotLegalBall(){ExtraType type=ExtraType.NO_BALL;assertFalse(type!=ExtraType.WIDE&&type!=ExtraType.NO_BALL);}
 @Test void byeIsLegalBall(){ExtraType type=ExtraType.BYE;assertTrue(type!=ExtraType.WIDE&&type!=ExtraType.NO_BALL);}
 @Test void overNotationUsesLegalBalls(){int legalBalls=17;assertEquals("2.5",(legalBalls/6)+"."+(legalBalls%6));}
}
