package com.cricket.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity @Table(name="deliveries", indexes={@Index(name="idx_delivery_match",columnList="matchId,id")})
public class Delivery {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private Long matchId; @Column(nullable=false) private int innings;
 @Column(nullable=false) private int runsOffBat; @Column(nullable=false) private int extraRuns;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private ExtraType extraType;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private WicketType wicketType;
 @Column(nullable=false) private boolean legalDelivery; @Column(nullable=false) private int totalRuns;
 private String commentary; @Column(nullable=false) private Instant createdAt=Instant.now();
 protected Delivery() {}
 public Delivery(Long matchId,int innings,int runsOffBat,int extraRuns,ExtraType extraType,WicketType wicketType,boolean legalDelivery,int totalRuns,String commentary){this.matchId=matchId;this.innings=innings;this.runsOffBat=runsOffBat;this.extraRuns=extraRuns;this.extraType=extraType;this.wicketType=wicketType;this.legalDelivery=legalDelivery;this.totalRuns=totalRuns;this.commentary=commentary;}
 public Long getId(){return id;} public Long getMatchId(){return matchId;} public int getInnings(){return innings;} public int getRunsOffBat(){return runsOffBat;} public int getExtraRuns(){return extraRuns;} public ExtraType getExtraType(){return extraType;} public WicketType getWicketType(){return wicketType;} public boolean isLegalDelivery(){return legalDelivery;} public int getTotalRuns(){return totalRuns;} public String getCommentary(){return commentary;} public Instant getCreatedAt(){return createdAt;}
}
