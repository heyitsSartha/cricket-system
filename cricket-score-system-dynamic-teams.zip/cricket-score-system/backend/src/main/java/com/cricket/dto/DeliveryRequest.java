package com.cricket.dto;
import com.cricket.entity.ExtraType;
import com.cricket.entity.WicketType;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
public record DeliveryRequest(@Min(0) @Max(6) int runsOffBat, @Min(0) @Max(7) int extraRuns, ExtraType extraType, WicketType wicketType, String commentary) {}
