package com.cricket.entity;
public enum MatchStatus { UPCOMING, LIVE, COMPLETED }
