package com.cricket.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;

@Entity @Table(name="matches")
public class CricketMatch {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String teamA;
 @Column(nullable=false) private String teamB;
 @Column(nullable=false) private String venue;
 @Column(nullable=false) private int oversLimit=20;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private MatchStatus status=MatchStatus.UPCOMING;
 private int innings=1; private String battingTeam; private String bowlingTeam;
 private int runs; private int wickets; private int legalBalls; private int target;
 private String summary;
 @Column(name="players_a", columnDefinition="TEXT") private String playersAData="";
 @Column(name="players_b", columnDefinition="TEXT") private String playersBData="";
 private Instant createdAt=Instant.now(); private long version;
 protected CricketMatch() {}
 public CricketMatch(String teamA,String teamB,String venue,int oversLimit){this(teamA,teamB,venue,oversLimit,java.util.List.of(),java.util.List.of());}
 public CricketMatch(String teamA,String teamB,String venue,int oversLimit,java.util.List<String> playersA,java.util.List<String> playersB){this.teamA=teamA;this.teamB=teamB;this.venue=venue;this.oversLimit=oversLimit;this.battingTeam=teamA;this.bowlingTeam=teamB;this.playersAData=String.join("\n",playersA);this.playersBData=String.join("\n",playersB);}
 public Long getId(){return id;} public String getTeamA(){return teamA;} public String getTeamB(){return teamB;} public String getVenue(){return venue;} public int getOversLimit(){return oversLimit;} public MatchStatus getStatus(){return status;} public int getInnings(){return innings;} public String getBattingTeam(){return battingTeam;} public String getBowlingTeam(){return bowlingTeam;} public int getRuns(){return runs;} public int getWickets(){return wickets;} public int getLegalBalls(){return legalBalls;} public int getTarget(){return target;} public String getSummary(){return summary;} public Instant getCreatedAt(){return createdAt;} public long getVersion(){return version;} public java.util.List<String> getPlayersA(){return playersAData==null||playersAData.isBlank()?java.util.List.of():java.util.Arrays.asList(playersAData.split("\n"));} public java.util.List<String> getPlayersB(){return playersBData==null||playersBData.isBlank()?java.util.List.of():java.util.Arrays.asList(playersBData.split("\n"));}
 public void setStatus(MatchStatus v){status=v;} public void setInnings(int v){innings=v;} public void setBattingTeam(String v){battingTeam=v;} public void setBowlingTeam(String v){bowlingTeam=v;} public void setRuns(int v){runs=v;} public void setWickets(int v){wickets=v;} public void setLegalBalls(int v){legalBalls=v;} public void setTarget(int v){target=v;} public void setSummary(String v){summary=v;} public void setVersion(long v){version=v;}
}
