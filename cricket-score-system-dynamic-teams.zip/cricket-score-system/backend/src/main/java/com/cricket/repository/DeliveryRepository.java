package com.cricket.repository;
import com.cricket.entity.Delivery;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface DeliveryRepository extends JpaRepository<Delivery,Long> { List<Delivery> findByMatchIdOrderByIdDesc(Long matchId); List<Delivery> findByMatchIdAndInningsOrderByIdAsc(Long matchId,int innings); }
