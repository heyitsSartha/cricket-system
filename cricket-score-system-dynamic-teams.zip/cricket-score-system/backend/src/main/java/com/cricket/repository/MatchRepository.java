package com.cricket.repository;
import com.cricket.entity.CricketMatch;
import com.cricket.entity.MatchStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface MatchRepository extends JpaRepository<CricketMatch,Long> { List<CricketMatch> findByStatusOrderByCreatedAtDesc(MatchStatus status); }
