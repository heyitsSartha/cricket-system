package com.cricket.dto;
import jakarta.validation.constraints.*;
import java.util.List;
public record MatchCreateRequest(
 @NotBlank @Size(max=100) String teamA,
 @NotBlank @Size(max=100) String teamB,
 @NotBlank @Size(max=150) String venue,
 @Min(1) @Max(50) int oversLimit,
 @NotEmpty @Size(min=2,max=11) List<@NotBlank @Size(max=100) String> playersA,
 @NotEmpty @Size(min=2,max=11) List<@NotBlank @Size(max=100) String> playersB
) {}
